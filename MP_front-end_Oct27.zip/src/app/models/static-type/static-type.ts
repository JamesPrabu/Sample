export interface StaticType {
    pk_id: string;
    lookup_type: string;
    lookup_name: string;
    lookup_value: string;
  }
  