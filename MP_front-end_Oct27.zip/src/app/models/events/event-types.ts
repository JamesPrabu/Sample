export class EventTypes {
    public static readonly const_EmailId: number = 1;
    public static readonly const_TextId: number = 2;
    public static readonly const_LogPhoneCallId: number = 3;
    public static readonly const_LogMeetingId: number = 4;
  }
  