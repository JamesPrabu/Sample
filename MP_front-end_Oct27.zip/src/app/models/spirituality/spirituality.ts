export interface Spirituality {
    pk_id: string;
    spirituality_desc: string;
  }