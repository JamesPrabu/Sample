export interface MobileCarriers {
    pk_id: string;
    carrier_name: string;
  }
  