export interface ITermsOfChristianFaith {
    terms_of_christian_faith_id: string;
    terms_of_christian_faith_name: string;
  }
  