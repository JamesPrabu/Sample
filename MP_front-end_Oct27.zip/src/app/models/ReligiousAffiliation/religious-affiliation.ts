export interface IReligiousAffiliation {
    religious_affiliation_id: string;
    religious_affiliation_name: string;
  }
  