import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'people-navigation-bar',
  templateUrl: './people-navigation-bar.component.html',
  styleUrls: ['./people-navigation-bar.component.scss']
})
export class PeopleNavigationBarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
