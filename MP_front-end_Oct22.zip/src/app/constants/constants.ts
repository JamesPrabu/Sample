export class Constants {
    public static readonly toastDurationForever: number = -1;
    public static readonly toastDurationSuccess: number = 6000;
    public static readonly toastDurationFail: number = 10000;
    public static readonly showCrmTwentyFourHourTime: boolean = false;
  }
  