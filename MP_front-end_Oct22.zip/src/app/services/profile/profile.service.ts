import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Profile } from 'src/app/models/profile/profile';
import { ProfileFactory } from 'src/app/models/profile/profile-factory';
import { ConfigurationService } from '../configuration/configuration.service';
import { SecureHttpClient } from '../secure-http-client/secure-http-client';

@Injectable({
    providedIn: 'root'
  })
  export class ProfileService {

    constructor(
        private secureHttpClient: SecureHttpClient,
        private configurationService: ConfigurationService,
        private profileFactory: ProfileFactory
      ) {
      }

  public get(): Observable<Profile[]> {
    return this.secureHttpClient.get(`${this.configurationService.getApiUrl()}/profiles`).pipe(
      map((profilesJson: any) => {
        console.log('profileservice  ', profilesJson)
        return profilesJson.map((profile) => this.profileFactory.buildPersonProfile(profile));
      }));
  }

  public personSoftDelete(personId: string): Observable<{ return_code: number }> {
    return this.secureHttpClient.get(`${this.configurationService.getApiUrl()}/profiles/${personId}/personSoftDelete`);
  }
  
  
  }